# git-flow Puppet Module for Boxen

## Usage

```puppet
include git-flow
```

## Required Puppet Modules

* `boxen`
* `homebrew`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
