export PYENV_ROOT=$BOXEN_HOME/pyenv

export PATH=$BOXEN_HOME/pyenv/bin:$PATH

eval "$(pyenv init -)"
